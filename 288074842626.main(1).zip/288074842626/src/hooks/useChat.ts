import { useState, useRef, useEffect } from 'react';
import { generateResponse } from '../mocks/chatResponses';

interface Message {
  id: string;
  content: string;
  isUser: boolean;
  timestamp: string;
}

interface UseChatOptions {
  // 智能体响应处理函数，用户可以提供自己的智能体逻辑
  agentResponseHandler?: (userMessage: string) => Promise<string>;
  // 欢迎消息配置
  welcomeMessage?: string;
}

export function useChat(options: UseChatOptions = {}) {
  const { 
    agentResponseHandler,
    welcomeMessage = '欢迎使用智能助手！我是一个AI聊天机器人，可以回答你的问题、提供建议或陪你聊天。请随时开始与我对话！'
  } = options;
  
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      content: welcomeMessage,
      isUser: false,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    }
  ]);
  
  const [inputValue, setInputValue] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // 自动滚动到底部
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return;

    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    const userMessage: Message = {
      id: `user-${Date.now()}`,
      content: inputValue,
      isUser: true,
      timestamp
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsTyping(true);

    try {
      let botResponseContent: string;
      
      // 如果用户提供了智能体响应处理函数，则使用它
      if (agentResponseHandler) {
        // 使用用户提供的智能体处理逻辑
        botResponseContent = await agentResponseHandler(inputValue);
      } else {
        // 否则使用模拟响应（为了演示目的）
        // 模拟网络延迟
        await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000));
        botResponseContent = generateResponse(inputValue);
      }
      
      const botResponse: Message = {
        id: `bot-${Date.now()}`,
        content: botResponseContent,
        isUser: false,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      
      setMessages(prev => [...prev, botResponse]);
    } catch (error) {
      console.error('智能体响应处理错误:', error);
      // 错误处理，可以根据需要自定义错误消息
      const errorResponse: Message = {
        id: `error-${Date.now()}`,
        content: '抱歉，处理您的请求时遇到了问题。请稍后再试。',
        isUser: false,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      
      setMessages(prev => [...prev, errorResponse]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  // 添加额外的方法，方便用户集成自己的智能体
  const addAgentMessage = (content: string) => {
    const timestamp = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const message: Message = {
      id: `agent-${Date.now()}`,
      content,
      isUser: false,
      timestamp
    };
    setMessages(prev => [...prev, message]);
  };

  return {
    messages,
    inputValue,
    setInputValue,
    isTyping,
    handleSendMessage,
    handleKeyPress,
    messagesEndRef,
    addAgentMessage
  };
}