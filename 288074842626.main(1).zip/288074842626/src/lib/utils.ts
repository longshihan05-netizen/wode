import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

// 合并Tailwind类名的工具函数
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// 格式化时间的工具函数
export function formatTime(date: Date): string {
  return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
}

// 处理异步操作的工具函数
export async function safeAsync<T>(
  fn: () => Promise<T>,
  errorMessage: string = "操作失败"
): Promise<T | { error: string }> {
  try {
    return await fn()
  } catch (error) {
    console.error(errorMessage, error)
    return { error: errorMessage }
  }
}
