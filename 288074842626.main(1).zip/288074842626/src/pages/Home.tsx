import { ChatInterface } from '@/components/ChatInterface';

// 示例：如何集成您自己的智能体
// 取消注释下面的代码，并替换为您的实际智能体API调用
/*
const customAgentHandler = async (userMessage: string): Promise<string> => {
  try {
    // 这里是调用您自己的智能体API的地方
    // const response = await fetch('您的智能体API地址', {
    //   method: 'POST',
    //   headers: {
    //     'Content-Type': 'application/json',
    //     // 如有需要，添加其他头信息
    //   },
    //   body: JSON.stringify({ message: userMessage })
    // });
    
    // const data = await response.json();
    // return data.response || '抱歉，智能体没有返回响应。';
    
    // 模拟API调用延迟
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // 示例响应（实际应用中应替换为真实API响应）
    return `这是来自您的自定义智能体的响应。您的问题是: "${userMessage}"`;
  } catch (error) {
    console.error('调用智能体API时出错:', error);
    return '抱歉，调用智能体时遇到了问题。请稍后再试。';
  }
};
*/

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-950 flex items-center justify-center p-4">
      <div className="w-full h-[80vh] max-w-4xl mx-auto">
        {/* 默认使用模拟智能体响应 */}
        <ChatInterface 
          // 要使用您自己的智能体，请取消下面的注释并传入您的处理函数
          // agentResponseHandler={customAgentHandler}
          // 可选：自定义欢迎消息
          // welcomeMessage="欢迎使用智能助手！请输入您的问题。"
        />
      </div>
    </div>
  );
}